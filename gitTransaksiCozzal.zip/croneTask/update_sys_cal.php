<?php

	if(isset($_GET['id'])){
		require("../../config/database.php");
		require("../class/ics_unit.php");
		$kd_unit = $_GET['id'];
		$unit = new Ics_unit($db);
		$unit->buildIcs($kd_unit);
	} 
?>